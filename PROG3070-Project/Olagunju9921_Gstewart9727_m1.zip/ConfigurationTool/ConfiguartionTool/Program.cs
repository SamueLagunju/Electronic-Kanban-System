using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ConfiguartionTool
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status = true;
            while (status)
            {
                try
                {
                    if (!TestDatabaseConnection())
                    {
                        Console.WriteLine("Connection To Database failed");
                        status = false;
                    }
                    else
                    {
                        Console.Write("Input Station Number To Configure (Press 0 to exit): ");
                        int chosenStationNumber = Convert.ToInt32(Console.ReadLine());
                       if(chosenStationNumber == 0) { status = false; }
                       else
                        {
                            UpdateData(chosenStationNumber);
                        }
                    }

                }

                catch (FormatException)
                {
                    Console.WriteLine("Invalid Input, Please try again.");
                    status = true;
                }
                catch (System.IO.IOException)
                {
                    Console.WriteLine("IO Exception error");
                    status = false;
                }
            }

            Console.WriteLine("Exiting Program");
            Environment.Exit(0);
        }

        private static void UpdateData(int stationNumber)
        {
            //Buffers to obtain user input to update the table information
            string experienceBuffer;
            float defectRateBuffer, speedBuffer;
            int harnessCapacity, reflectorCapacity, housingCapacity, lensCapacity, bulbCapacity, bezelCapacity;

            string connString = null;   //String used to connect to the database
            connString = "Server= localhost; Initial Catalog=Kanban; Integrated Security=SSPI;";
            SqlConnection connection = new SqlConnection(connString);   //Creatinng a connectiong
            try
            {
                connection.Open();  //Opening the connection to the database

                SqlCommand Command = new SqlCommand("DELETE FROM [dbo].[Station Config Table] WHERE[Station Number] =" + stationNumber, connection);

                int numberOfRecords = Command.ExecuteNonQuery();
                if(numberOfRecords == 0)
                {
                    Console.WriteLine("No records found");
                    connection.Close(); //Close the connection
                }

                else
                {
                    //Obtaining values from the user to update the information
                    Console.Write("Input Experience Level: ");
                    experienceBuffer = Console.ReadLine();
                    Console.Write("Input Defect rate: ");
                    defectRateBuffer = float.Parse(Console.ReadLine());
                    Console.Write("Input Harness Capacity: ");
                    harnessCapacity = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input Reflector Capacity: ");
                    reflectorCapacity = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input Housing Capacity: ");
                    housingCapacity = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input Lens Capacity: ");
                    lensCapacity = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input Bulb Capacity: ");
                    bulbCapacity = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input Bezel Capacity: ");
                    bezelCapacity = Convert.ToInt32(Console.ReadLine());

                    Command = new SqlCommand("INSERT INTO [dbo].[Station Config Table] ([Station Number],[Experience] ,[Defect Rate],[Speed]" +
                                               ",[Harness Capacity] ,[Reflector Capacity],[Housing Capacity],[Lens Capacity], [Bulb Capacity] ,[Bezel Capacity]) VALUES (@textValue);", connection);
                }
            }

            catch(Exception)
            {
                Console.WriteLine("Dealing with the exception");
            }
        }


        /*
        * Function		:   FillChart(int flag)
        * Description	:   Fills the column based on the category and subcategory selection
        *                   From the combobox
        * Parameters	:   int flag
        * Returns		:   N/A
        */
        private static bool TestDatabaseConnection()
        {
            bool status;    //Status to keep track of the test connection
            string connString = null;   //String used to connect to the database
            connString = "Server= localhost; Initial Catalog=FoodMar; Integrated Security=SSPI;";
            SqlConnection connection = new SqlConnection(connString);   //Creatinng a connectiong
            try
            {
                connection.Open();  //Opening the connection to the database
                status = true;  //If no exception is thrown, set status to true
                connection.Close(); //Close the connection
            }
            //If any exception was thrown, set status to false
            catch (Exception) { status = false; }
            return status;
        }
    }
}
