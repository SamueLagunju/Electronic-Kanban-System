USE [Kanban System Data]
GO

/****** Object:  Table [dbo].[System Config Table]    Script Date: 2019-03-19 6:51:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[System Config Table](
	[Time Scale] [float] NOT NULL
) ON [PRIMARY]
GO

